clear all;clc;
G_theo=0.1:0.01:2;
L=1;
switch L
    case 1
        RA_degree=[0,0.5112,0.266,0,0,0,0,0.2228];
    case 2
        RA_degree=[0,0.6607,0.1605,0,0,0,0,0.1788];
    case 3
        RA_degree=[0,0.7947,0.047,0,0,0,0,0.1583];
    case 4
        RA_degree=[0,0.837,0,0,0,0,0,0.163];
    case 5
        RA_degree=[0,0.8499,0,0,0,0,0,0.1501];
end

for i=1:length(RA_degree)
    Alpha_x(i)=i*RA_degree(i);
end
Alpha_1=sum(Alpha_x);
q=1;
Imax=1000;
for it=1:Imax
    p=f_calc(q,G_theo,L,Alpha_1);
    q=lambda_calc(p,Alpha_x);
end
PLR_theo=q;
T_theo=G_theo.*(1-PLR_theo);
figure(1);
semilogy(G_theo,PLR_theo);
axis([min(G_theo) max(G_theo) 10^-5 1])
figure(2);
plot(G_theo,T_theo);
axis([min(G_theo) max(G_theo) 0 max(T_theo)+0.1])