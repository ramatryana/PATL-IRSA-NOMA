function decodedUser=decoding(G,N_iter,tSINR)
sDegree=1;
decodedUser=[];
iter=1;
while sDegree==1 && iter<=N_iter
    sDegree=0;
    for iN=1:size(G,2)
        if sum(G(:,iN))>0
            [power_order,index]=sort(G(:,iN),'descend');
            SINR=10*log10(power_order(1)/(sum(power_order(2:end))+1));
            if SINR>=tSINR
                cek=find(decodedUser==index(1));
                if isempty(cek)
                    decodedUser=[decodedUser,index(1)];
                end
                G(index(1),:)=0;
                sDegree=1;
            end
        end
    end
    iter=iter+1;
end