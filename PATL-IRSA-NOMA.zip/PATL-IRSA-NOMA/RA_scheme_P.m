function [T_trial,PLR_trial]=RA_scheme_P(G_PLR,G_T,N,RA_degree,nTrial,nFrame,N_iter,L,tSINR)
M=round(G_PLR*N);
PLR_trial=0;
T_trial=0;
for iTrial=1:nTrial
    lossFrame=0;
    for iFrame=1:nFrame
        G=matrix_generate(M,N,RA_degree,1,L,tSINR);
        decodedUser=decoding(G,N_iter,tSINR);
        lossFrame=lossFrame+(M-length(decodedUser));
    end
    PLR=lossFrame/(nFrame*M);
    T=(G_T)*(1-PLR);
    PLR_trial=PLR_trial+PLR/nTrial;
    T_trial=T_trial+T/nTrial;
    iTrial
end
