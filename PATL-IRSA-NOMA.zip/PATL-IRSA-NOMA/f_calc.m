function out=f_calc(in,G,L,Alpha_1)
for r=1:L
    atas=(in.*G*Alpha_1/L).^(r-1);
    bawah=factorial(r-1)*factorial(L-r);
    hasil(r,:)=atas./bawah;
end
out=1-exp(-in.*G*Alpha_1)*factorial(L-1).*sum(hasil,1);