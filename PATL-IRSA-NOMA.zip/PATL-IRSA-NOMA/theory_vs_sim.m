clear all;clc;close all;
L=1;
nTrial=100;
nFrame=1;
tSINR=3;
for N=200
    N_iter=1000;
    step=0.2;
    maks_G=2;
    M=[0.1*N:0.1*N:0.9*N,N:step*N:maks_G*N];
    
    G_sim=M/N;
    G_theo=0.1:0.01:maks_G;
    RA_degree=[0,0.5,0.28,0,0,0,0,0.22];
    for i=1:length(RA_degree)
        Alpha_x(i)=i*RA_degree(i);
    end
    Alpha_1=sum(Alpha_x);
    q=1;
    Imax=N_iter;
    for it=1:Imax
        q=lambda_calc(1-exp(-q.*G_theo*Alpha_1),Alpha_x);
    end
    PLR_theo=q;
    T_theo=G_theo.*(1-PLR_theo);
    
    for iUser=1:length(G_sim)
        [T_sim(iUser),PLR_sim(iUser)]=RA_scheme(G_sim(iUser),N,RA_degree,nTrial,nFrame,N_iter,L,tSINR);
    end
    
    save (['IRSA-',num2str(N),'-',num2str(nTrial),'-',num2str(nFrame),'-',num2str(step),'-',num2str(maks_G),'-','.mat']);
end
figure(1);
semilogy(G_theo,PLR_theo,'-r');hold on;
semilogy(G_sim,PLR_sim,'--rd');hold on;
axis([0.1 maks_G 10^-5 L])

figure(2);
plot(G_theo,T_theo,'-r');hold on;
plot(G_sim,T_sim,'--rd');hold on;
axis([0.1 maks_G 0 L])