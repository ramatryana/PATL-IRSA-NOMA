clear all;clc;
nTrial=10000;
nFrame=1;
tSINR=3;
for L=5
    maks_G=3;
    for N=1000
        N_iter=10000;
        step=0.1;
        M=[0.1*N:0.1*N:0.9*N,N:step*N:maks_G*N];
        G_sim=M/N;
        G_theo=0.1:0.01:maks_G;
        switch L
            case 1
                RA_degree=[0,0.5112,0.266,0,0,0,0,0.2228];
            case 2
                RA_degree=[0,0.6607,0.1605,0,0,0,0,0.1788];
            case 3
                RA_degree=[0,0.7947,0.047,0,0,0,0,0.1583];
            case 4
                RA_degree=[0,0.837,0,0,0,0,0,0.163];
            case 5
                RA_degree=[0,0.8499,0,0,0,0,0,0.1501];
        end
        for i=1:length(RA_degree)
            Alpha_x(i)=i*RA_degree(i);
        end
        Alpha_1=sum(Alpha_x);
        q=1;
        p=f_calc(q,G_theo,L,Alpha_1);
        Imax=N_iter;
        for it=1:Imax
            lambda_p=lambda_calc(p,Alpha_x);
            p=f_calc(lambda_p,G_theo,L,Alpha_1);
        end
        PLR_theo=p;
        T_theo=G_theo.*(1-PLR_theo);
        
        for iUser=1:length(G_sim)
            [T_sim(iUser),PLR_sim(iUser)]=RA_scheme(G_sim(iUser),N,RA_degree,nTrial,nFrame,N_iter,L,tSINR);
        end
        
        save ([cd,'\mat\IRSA-NOMA-',num2str(L),'-',num2str(N),'-',num2str(nTrial),'-',num2str(N_iter),'-',num2str(maks_G),'.mat']);
    end
end
figure(1);
semilogy(G_theo,PLR_theo,'-r');hold on;
semilogy(G_sim,PLR_sim,'--rd');hold on;
axis([0.1 maks_G 10^-5 1])

figure(2);
plot(G_theo,T_theo,'-r');hold on;
plot(G_sim,T_sim,'--rd');hold on;
axis([0.1 maks_G 0 maks_G])