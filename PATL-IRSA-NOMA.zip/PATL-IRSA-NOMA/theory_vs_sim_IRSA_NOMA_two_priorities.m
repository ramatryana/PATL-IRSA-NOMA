clear all;clc;
nTrial=10000;
nFrame=1;
tSINR=3;
alpha=0.1;
for L=2
    maks_G=3;
    for N=500
        N_iter=10000;
        step=0.1;
        switch L
            case 1
                RA_degree=[0,0.5112,0.266,0,0,0,0,0.2228];
                G_max=0.92;
                M=[0.1*N:0.1*N:0.8*N,G_max*N,N:step*N:maks_G*N];
            case 2
                RA_degree=[0,0.6607,0.1605,0,0,0,0,0.1788];
                G_max=1.34;
                M=[0.1*N:0.1*N:1.2*N,G_max*N,1.4*N:step*N:maks_G*N];
            case 3
                RA_degree=[0,0.7947,0.047,0,0,0,0,0.1583];
                G_max=1.75;
                M=[0.1*N:0.1*N:1.6*N,G_max*N,1.8*N:step*N:maks_G*N];
            case 4
                RA_degree=[0,0.837,0,0,0,0,0,0.163];
                G_max=2.11;
                M=[0.1*N:0.1*N:2*N,G_max*N,2.2*N:step*N:maks_G*N];
            case 5
                RA_degree=[0,0.8499,0,0,0,0,0,0.1501];
                G_max=2.42;
                M=[0.1*N:0.1*N:2.3*N,G_max*N,2.5*N:step*N:maks_G*N];
        end
        G_sim=M/N;
        G_theo=0.1:0.01:maks_G;
        G_ED_theo=alpha*G_theo;
        G_RD_theo=(1-alpha)*G_theo;
        for i=1:length(RA_degree)
            Alpha_x(i)=i*RA_degree(i);
        end
        Alpha_1=sum(Alpha_x);
        %% ED
        q=1;
        Imax=10000;
        for it=1:Imax
            p=f_calc(q,G_ED_theo+G_RD_theo,L,Alpha_1);
            q=lambda_calc(p,Alpha_x);
        end
        PLR_ED_theo=q;
        T_ED_theo=G_ED_theo.*(1-PLR_ED_theo);
        
        %% RD
        q=1;
        Imax=10000;
        for it=1:Imax
            p=f_calc(q,G_ED_theo+G_RD_theo,L,Alpha_1);
            q=lambda_calc(p,Alpha_x);
        end
        PLR_RD_theo=q;
        T_RD_theo=G_RD_theo.*(1-PLR_RD_theo);
        
        
        G_ED_sim=alpha*G_sim;
        G_RD_sim=(1-alpha)*G_sim;
        for iUser=1:length(G_sim)
            [T_ED_sim(iUser),PLR_ED_sim(iUser)]=RA_scheme_P(G_sim(iUser),G_ED_sim(iUser),N,RA_degree,nTrial,nFrame,N_iter,L,tSINR);
        end
        for iUser=1:length(G_sim)
            [T_RD_sim(iUser),PLR_RD_sim(iUser)]=RA_scheme_P(G_sim(iUser),G_RD_sim(iUser),N,RA_degree,nTrial,nFrame,N_iter,L,tSINR);
        end
        
        save ([cd,'\mat\IRSA-NOMA-2P-',num2str(L),'-',num2str(alpha),'-',num2str(N),'-',num2str(nTrial),'-',num2str(N_iter),'.mat']);
    end
end