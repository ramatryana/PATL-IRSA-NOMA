function G=matrix_generate(M,N,D,pAccess,L,tSINR)
for iL=1:L
    power(iL)=tSINR*(tSINR+1)^(L-iL);
end
M_D=round(M*D);
if sum(M_D)>M
    pos=find(M_D~=0);
    M_D(pos(1))=M_D(pos(1))-(sum(M_D)-M);
end
G=zeros(M,N);
awal=1;
for iUserD=1:length(M_D)
    if M_D(iUserD)~=0
        for iUser=awal:awal+M_D(iUserD)-1
            if rand<=pAccess
                rand_seq=randperm(N);
                iDegree=iUserD;
                for iReplica=1:iDegree  
                    rand_pow=randperm(L);
                    G(iUser,rand_seq(iReplica))=power(rand_pow(1));
                end
            end
        end
        awal=awal+M_D(iUserD);
    end
end


