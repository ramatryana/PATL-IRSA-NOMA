clear all;clc;
nTrial=10000;
nFrame=1;
tSINR=3;
d_marker={'x','o','s','d','^'};
d_marker_RD={'*','+','h','>','<'}';
L=2;
i_label=1;
maks_G=3;
for N=200
    N_iter=10000;
    step=0.1;
    %         load ([cd,'\mat\IRSA-NOMA-2P-',num2str(L),'-',num2str(alpha),'-',num2str(N),'-',num2str(nTrial),'-',num2str(N_iter),'.mat']);
    Figure1=figure(1);
    FigW=7;
    FigH=5;
    set(Figure1,'PaperUnits','inches','Papersize',[FigW,FigH],...
        'Paperposition',[0,0,FigW,FigH],'Units','Inches',...
        'Position',[0,0,FigW,FigH]);
    
    %         if L==1
    %             plot(G_sim([1:2:30,30]),T_ED_sim([1:2:30,30]),['--r',d_marker{L}],'linewidth',1,'markersize',8);hold on;
    %             plot(G_sim([1:2:30,30]),T_RD_sim([1:2:30,30]),['--b',d_marker{L}],'linewidth',1,'markersize',8);hold on;
    %         else
    %             h=plot(G_sim([1:2:30,30]),T_ED_sim([1:2:30,30]),['--r',d_marker{L}],'linewidth',1,'markersize',8);hold on;
    %             h.Annotation.LegendInformation.IconDisplayStyle = 'off';
    %             h=plot(G_sim([1:2:30,30]),T_RD_sim([1:2:30,30]),['--b',d_marker{L}],'linewidth',1,'markersize',8);hold on;
    %             h.Annotation.LegendInformation.IconDisplayStyle = 'off';
    %         end
    subplot(121);
    for alpha=0.1:0.1:0.4
        load ([cd,'\mat\PATL-IRSA-NOMA-2P-N200-',num2str(L),'-',num2str(alpha),'-',num2str(N),'-',num2str(nTrial),'-',num2str(N_iter),'.mat']);
        plot(G_sim([1:2:50,50]),T_ED_sim([1:2:50,50]),['-r',d_marker{i_label}],'linewidth',1,'markersize',8);hold on;
        plot(G_sim([1:2:50,50]),T_RD_sim([1:2:50,50]),['-b',d_marker_RD{i_label}],'linewidth',1,'markersize',8);hold on;
        d_legend{(i_label-1)*2+1,1}=['ED $\alpha=',num2str(alpha),'$'];
        d_legend{(i_label-1)*2+2,1}=['RD $\alpha=',num2str(alpha),'$'];
        i_label=i_label+1;
    end
        axis([0.1 maks_G 0 2])
        legend(d_legend,'interpreter','latex','fontsize',12,'numcolumns',2);
    xlabel('$G$ (MTD/slot)','interpreter','latex','fontsize',16);
    ylabel('$T$ (packet/slot)','interpreter','latex','fontsize',16)
    subplot(122);
    d_legend=[];
    i_label=1;
    for alpha=0.6:0.1:0.9
        load ([cd,'\mat\PATL-IRSA-NOMA-2P-N200-',num2str(L),'-',num2str(alpha),'-',num2str(N),'-',num2str(nTrial),'-',num2str(N_iter),'.mat']);
        plot(G_sim([1:2:50,50]),T_ED_sim([1:2:50,50]),['-r',d_marker{i_label}],'linewidth',1,'markersize',8);hold on;
        plot(G_sim([1:2:50,50]),T_RD_sim([1:2:50,50]),['-b',d_marker_RD{i_label}],'linewidth',1,'markersize',8);hold on;
        d_legend{(i_label-1)*2+1,1}=['ED $\alpha=',num2str(alpha),'$'];
        d_legend{(i_label-1)*2+2,1}=['RD $\alpha=',num2str(alpha),'$'];
        i_label=i_label+1;
    end
    axis([0.1 maks_G 0 2])
    legend(d_legend,'interpreter','latex','fontsize',12,'numcolumns',2);
    xlabel('$G$ (MTD/slot)','interpreter','latex','fontsize',16);
    ylabel('$T$ (packet/slot)','interpreter','latex','fontsize',16)
    
    
    
end
