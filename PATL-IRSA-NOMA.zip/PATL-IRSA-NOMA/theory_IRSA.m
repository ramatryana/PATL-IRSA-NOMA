clear all;clc;
G_theo=0.1:0.01:2;
RA_degree=[0,0.5,0.28,0,0,0,0,0.22];
for i=1:length(RA_degree)
Alpha_x(i)=i*RA_degree(i);
end
Alpha_1=sum(Alpha_x);
q=1;
Imax=10000;
for it=1:Imax
    q=lambda_calc(1-exp(-q.*G_theo*Alpha_1),Alpha_x);
end
PLR_theo=q;
T_theo=G_theo.*(1-PLR_theo);
semilogy(G_theo,PLR_theo);
axis([min(G_theo) max(G_theo) 10^-5 1]);
figure
plot(G_theo,T_theo);
axis([min(G_theo) max(G_theo) 0 max(T_theo)+0.1]);