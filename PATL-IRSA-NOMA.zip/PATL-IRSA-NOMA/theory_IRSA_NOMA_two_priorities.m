clear all;clc;
G_theo=0.1:0.01:3;
L=5;
alpha=0.1;
switch L
    case 1
        RA_degree=[0,0.5112,0.266,0,0,0,0,0.2228];
    case 2
        RA_degree=[0,0.6607,0.1605,0,0,0,0,0.1788];
    case 3
        RA_degree=[0,0.7947,0.047,0,0,0,0,0.1583];
    case 4
        RA_degree=[0,0.837,0,0,0,0,0,0.163];
    case 5
        RA_degree=[0,0.8499,0,0,0,0,0,0.1501];
end

G_ED_theo=alpha*G_theo;
G_RD_theo=(1-alpha)*G_theo;
for i=1:length(RA_degree)
    Alpha_x(i)=i*RA_degree(i);
end
Alpha_1=sum(Alpha_x);
%% ED
q=1;
Imax=10000;
for it=1:Imax
    p=f_calc(q,G_ED_theo+G_RD_theo,L,Alpha_1);
    q=lambda_calc(p,Alpha_x);
end
PLR_ED_theo=q;
T_ED_theo=G_ED_theo.*(1-PLR_ED_theo);

%% RD
q=1;
Imax=10000;
for it=1:Imax
    p=f_calc(q,G_ED_theo+G_RD_theo,L,Alpha_1);
    q=lambda_calc(p,Alpha_x);
end
PLR_RD_theo=q;
T_RD_theo=G_RD_theo.*(1-PLR_RD_theo);
figure(1);
semilogy(G_theo,PLR_ED_theo,'--r');hold on;
semilogy(G_theo,PLR_RD_theo,'-.b');
axis([min(G_theo) max(G_theo) 10^-5 1])
figure(2);
plot(G_theo,T_ED_theo,'--r');hold on;
plot(G_theo,T_RD_theo,'-.b');hold on;
axis([min(G_theo) max(G_theo) 0 max(T_RD_theo)+0.1])