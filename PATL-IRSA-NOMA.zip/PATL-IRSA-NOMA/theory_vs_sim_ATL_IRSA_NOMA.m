clear all;clc;
nTrial=10000;
nFrame=1;
tSINR=3;
for L=2
    maks_G=3;
    switch L
        case 1
            RA_degree=[0,0.5112,0.266,0,0,0,0,0.2228];
            G_max=0.95;
        case 2
            RA_degree=[0,0.6607,0.1605,0,0,0,0,0.1788];
            G_max=1.44;
        case 3
            RA_degree=[0,0.7947,0.047,0,0,0,0,0.1583];
            G_max=1.76;
        case 4
            RA_degree=[0,0.837,0,0,0,0,0,0.163];
            G_max=2.12;
        case 5
            RA_degree=[0,0.8499,0,0,0,0,0,0.1501];
            G_max=2.43;
    end
    for N=[200,500,1000]
        N_iter=10000;
        step=0.1;
        M=[0.1*N:0.1*N:0.9*N,N:step*N:maks_G*N];
        %         load ([cd,'\mat\ATL-IRSA-NOMA-',num2str(L),'-',num2str(N),'-',num2str(nTrial),'-',num2str(N_iter),'-',num2str(maks_G),'.mat']);
        G_sim=M/N;
        
        G_ATL_sim=G_sim;
        selisih=abs(G_sim-floor(G_max*10)/10);
        pos_min=find(selisih==min(selisih));
        G_min=G_sim(pos_min);
        pos=find(G_sim>=G_min);
        G_ATL_sim(pos)=G_min;
        
        
        
        G_theo=0.1:0.01:maks_G;
        G_ATL=G_theo;
        pos=find(G_theo>=G_min);
        G_ATL(pos)=G_min;
        RA_degree=[0,1];
        
        for i=1:length(RA_degree)
            Alpha_x(i)=i*RA_degree(i);
        end
        Alpha_1=sum(Alpha_x);
        q=1;
        p=f_calc(q,G_ATL,L,Alpha_1);
        Imax=10000;
        for it=1:Imax
            lambda_p=lambda_calc(p,Alpha_x);
            p=f_calc(lambda_p,G_ATL,L,Alpha_1);
        end
        PLR_theo=p;
        T_theo=G_ATL.*(1-PLR_theo);
        
        for iUser=1:length(G_sim)
            [T_sim(iUser),PLR_sim(iUser)]=RA_scheme(G_ATL_sim(iUser),N,RA_degree,nTrial,nFrame,N_iter,L,tSINR);
        end
        
        save ([cd,'\mat\ATL-IRSA-NOMA-',num2str(L),'-',num2str(N),'-',num2str(nTrial),'-',num2str(N_iter),'-',num2str(maks_G),'.mat']);
    end
end
figure(1);
semilogy(G_theo,PLR_theo,'-r');hold on;
semilogy(G_sim,PLR_sim,'--rd');hold on;
axis([0.1 maks_G 10^-5 1])

figure(2);
plot(G_theo,T_theo,'-r');hold on;
plot(G_sim,T_sim,'--rd');hold on;
axis([0.1 maks_G 0 maks_G])