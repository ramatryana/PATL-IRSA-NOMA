clear all;clc;
nTrial=10000;
nFrame=1;
tSINR=3;
d_marker={'x','o','s','d','^'};
d_marker_RD={'*','+','h','>','<'};
alpha=0.5;
% d_legend{1,1}='IRSA-NOMA ED';
% d_legend{2,1}='IRSA-NOMA RD';
for N=200
    N_iter=10000;
    step=0.1;
    %         load ([cd,'\mat\IRSA-NOMA-2P-',num2str(L),'-',num2str(alpha),'-',num2str(N),'-',num2str(nTrial),'-',num2str(N_iter),'.mat']);
    Figure1=figure(1);
    FigW=6;
    FigH=5;
    set(Figure1,'PaperUnits','inches','Papersize',[FigW,FigH],...
        'Paperposition',[0,0,FigW,FigH],'Units','Inches',...
        'Position',[0,0,FigW,FigH]);
    
    %         if L==1
    %             plot(G_sim([1:2:30,30]),T_ED_sim([1:2:30,30]),['--r',d_marker{L}],'linewidth',1,'markersize',8);hold on;
    %             plot(G_sim([1:2:30,30]),T_RD_sim([1:2:30,30]),['--b',d_marker{L}],'linewidth',1,'markersize',8);hold on;
    %         else
    %             h=plot(G_sim([1:2:30,30]),T_ED_sim([1:2:30,30]),['--r',d_marker{L}],'linewidth',1,'markersize',8);hold on;
    %             h.Annotation.LegendInformation.IconDisplayStyle = 'off';
    %             h=plot(G_sim([1:2:30,30]),T_RD_sim([1:2:30,30]),['--b',d_marker{L}],'linewidth',1,'markersize',8);hold on;
    %             h.Annotation.LegendInformation.IconDisplayStyle = 'off';
    %         end
    for L=1:5
        load ([cd,'\mat\PATL-IRSA-NOMA-2P-N200-',num2str(L),'-',num2str(alpha),'-',num2str(N),'-',num2str(nTrial),'-',num2str(N_iter),'.mat']);
        plot(G_sim([1:1:50]),T_ED_sim([1:1:50]),['-r',d_marker{L}],'linewidth',1,'markersize',8);hold on;
        d_legend{L,1}=['ED $K=',num2str(L),'$'];
    end
    for L=1:5
        load ([cd,'\mat\PATL-IRSA-NOMA-2P-N200-',num2str(L),'-',num2str(alpha),'-',num2str(N),'-',num2str(nTrial),'-',num2str(N_iter),'.mat']);
        plot(G_sim([1:1:50]),T_RD_sim([1:1:50]),['-b',d_marker_RD{L}],'linewidth',1,'markersize',8);hold on;
        
        d_legend{5+L ,1}=['RD $K=',num2str(L),'$'];
        axis([0.1 maks_G 0 2.5])
    end
    
    xlabel('Normalized offered traffic ($G$) (MTD/slot)','interpreter','latex','fontsize',16);
    ylabel('Normlalized throughput ($T$) (packet/slot)','interpreter','latex','fontsize',16)
    
    
end
legend(d_legend,'interpreter','latex','fontsize',14,'numcolumns',2);