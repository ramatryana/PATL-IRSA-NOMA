clear all;clc;
nTrial=10000;
nFrame=1;
tSINR=3;
alpha=0.1;
for L=2
    maks_G=3;
    for N=200
        N_iter=10000;
        step=0.1;
        
        Figure1=figure(1);
        FigW=6;
        FigH=5;
        set(Figure1,'PaperUnits','inches','Papersize',[FigW,FigH],...
            'Paperposition',[0,0,FigW,FigH],'Units','Inches',...
            'Position',[0,0,FigW,FigH]);
        
                load ([cd,'\mat\PATL-IRSA-NOMA-2P-N200-',num2str(L),'-',num2str(alpha),'-',num2str(N),'-',num2str(nTrial),'-',num2str(N_iter),'.mat']);
                semilogy(G_theo,PLR_ED_theo,'-r');hold on;
                h=semilogy(G_theo,PLR_RD_theo,'-b');hold on;
                h.Annotation.LegendInformation.IconDisplayStyle = 'off';
                semilogy(G_sim,PLR_ED_sim,'-sr','linewidth',1,'markersize',8);hold on;
                semilogy(G_sim,PLR_RD_sim,'-db','linewidth',1,'markersize',8);
        
        load([cd,'\mat\IRSA-NOMA-2P-N200-',num2str(L),'-',num2str(alpha),'-',num2str(N),'-',num2str(nTrial),'-',num2str(N_iter),'.mat']);
        h=semilogy(G_theo,PLR_ED_theo,'-r');hold on;
                h.Annotation.LegendInformation.IconDisplayStyle = 'off';
        h=semilogy(G_theo,PLR_RD_theo,'-b');hold on;
        h.Annotation.LegendInformation.IconDisplayStyle = 'off';
        semilogy(G_sim,PLR_ED_sim,'-sr','linewidth',1,'markersize',8);hold on;
        semilogy(G_sim,PLR_RD_sim,'-db','linewidth',1,'markersize',8);
        
        axis([0.1 maks_G 10^-5 1])
        
%         legend('Asymptotic','Sim. Proposed ED','Sim. Proposed RD',...
%             'interpreter','latex','fontsize',12,'numcolumns',1);
%         xlabel('Normalized Load ($G$) (MTD/slot)','interpreter','latex','fontsize',12);
%         ylabel('PLR','interpreter','latex','fontsize',14)
%         
        
        Figure1=figure(2);
        FigW=6;
        FigH=5;
        set(Figure1,'PaperUnits','inches','Papersize',[FigW,FigH],...
            'Paperposition',[0,0,FigW,FigH],'Units','Inches',...
            'Position',[0,0,FigW,FigH]);
        
        
        
        
        
                load ([cd,'\mat\PATL-IRSA-NOMA-2P-N200-',num2str(L),'-',num2str(alpha),'-',num2str(N),'-',num2str(nTrial),'-',num2str(N_iter),'.mat']);
                plot(G_theo,T_ED_theo,'-k','linewidth',1,'markersize',8);hold on;
                h=plot(G_theo,T_ED_theo,'-r','linewidth',1,'markersize',8);hold on;
                h.Annotation.LegendInformation.IconDisplayStyle = 'off';
                h=plot(G_theo,T_RD_theo,'-b','linewidth',1,'markersize',8);hold on;
                h.Annotation.LegendInformation.IconDisplayStyle = 'off';
                plot(G_sim,T_ED_sim,'--sr','linewidth',1,'markersize',8);hold on;
                plot(G_sim,T_RD_sim,'--db','linewidth',1,'markersize',8);
        
        load ([cd,'\mat\IRSA-NOMA-2P-N200-',num2str(L),'-',num2str(alpha),'-',num2str(N),'-',num2str(nTrial),'-',num2str(N_iter),'.mat']);
        h=plot(G_theo,T_ED_theo,'-m','linewidth',1,'markersize',8);hold on;
        h.Annotation.LegendInformation.IconDisplayStyle = 'off';
        h=plot(G_theo,T_RD_theo,'-k','linewidth',1,'markersize',8');hold on;
        h.Annotation.LegendInformation.IconDisplayStyle = 'off';
        plot(G_sim,T_ED_sim,'--om','linewidth',1,'markersize',8);hold on;
        plot(G_sim,T_RD_sim,'--^k','linewidth',1,'markersize',8);
         axis([0.1 maks_G 0 1.5])
        
        legend('Asymptotic','Sim. Proposed ED','Sim. Proposed RD','Sim. Conventional ED','Sim. Conventional RD',...
            'interpreter','latex','fontsize',14,'numcolumns',1,'FontName','Arial');
        xlabel('Normalized offered traffic ($G$) (MTD/slot)','interpreter','latex','fontsize',16,'FontName','Arial');
        ylabel('Normlaized throughput ($T$) (packet/slot)','interpreter','latex','fontsize',16,'FontName','Arial')
    end
end