clear all;clc;
nTrial=10000;
nFrame=1;
tSINR=3;
L=1;
maks_G=3;
N_iter=10000;
step=0.1;
Figure1=figure(1);
FigW=6;
FigH=5;
set(Figure1,'PaperUnits','inches','Papersize',[FigW,FigH],...
    'Paperposition',[0,0,FigW,FigH],'Units','Inches',...
    'Position',[0,0,FigW,FigH]);

load ([cd,'\mat\ATL-IRSA-NOMA-',num2str(L),'-',num2str(1000),'-',num2str(nTrial),'-',num2str(N_iter),'-',num2str(maks_G),'.mat']);
semilogy(G_theo,PLR_theo,'-k','linewidth',1,'markersize',8);hold on;
% h.Annotation.LegendInformation.IconDisplayStyle = 'off';
load ([cd,'\mat\ATL-IRSA-NOMA-',num2str(L),'-',num2str(200),'-',num2str(nTrial),'-',num2str(N_iter),'-',num2str(maks_G),'.mat']);
semilogy(G_sim(1:1:end),PLR_sim(1:1:end),'--ko','linewidth',1,'markersize',8);hold on;
load ([cd,'\mat\ATL-IRSA-NOMA-',num2str(L),'-',num2str(500),'-',num2str(nTrial),'-',num2str(N_iter),'-',num2str(maks_G),'.mat']);
semilogy(G_sim(1:1:end),PLR_sim(1:1:end),'--ks','linewidth',1,'markersize',8);hold on;
load ([cd,'\mat\ATL-IRSA-NOMA-',num2str(L),'-',num2str(1000),'-',num2str(nTrial),'-',num2str(N_iter),'-',num2str(maks_G),'.mat']);
semilogy(G_sim(1:1:end),PLR_sim(1:1:end),'--kd','linewidth',1,'markersize',8);hold on;

axis([0.1 maks_G 10^-4 1])

legend('Asymptotic','Simulated $N=200$','Simulated $N=500$','Simulated $N=1000$',...
    'interpreter','latex','fontsize',14,'numcolumns',1);
xlabel('Normalized Load ($G$) (MTD/slot)','interpreter','latex','fontsize',16);
ylabel('PLR','interpreter','latex','fontsize',16)